# Pointfrip
**programmierbarer Calculator**

\
\
Pointfrip Calculator für Android, [Beschreibung der App](https://android-developers.de/thread/8404-pointfrip-calculator-f%C3%BCr-android/) \
Download der [APK](https://github.com/pointfrip/calculator/blob/main/apk/debug/app-debug.apk) auf das Händi und installieren. \
[Schnelle Einleitung](https://github.com/pointfrip/calculator/blob/main/quickinfo.pdf) mit Quickinfo.pdf (DE)

![calculator-image](https://raw.githubusercontent.com/pointfrip/calculator/main/pixel2bimage.png)

